# Сборка APK через Codemagic с телефона

1. Создайте аккаунт на https://codemagic.io/.
2. Подготовьте репозиторий с содержимым этого проекта. Проще всего создать приватный GitHub-репозиторий и загрузить в него файлы проекта.
3. В Codemagic откройте Applications → Add application.
4. Подключите GitHub и выберите репозиторий.
5. Выберите Native Android.
6. Убедитесь, что в корне репозитория лежит codemagic.yaml.
7. Откройте Start new build.
8. Выберите workflow `android-debug` и ветку `main`.
9. Запустите сборку.
10. После успешной сборки откройте Artifacts и скачайте `app-debug.apk` на телефон.

Это debug APK. Для личной установки на телефон отдельная подпись Google Play не требуется.

Для release APK позже можно добавить Android keystore в Codemagic и отдельный workflow.
