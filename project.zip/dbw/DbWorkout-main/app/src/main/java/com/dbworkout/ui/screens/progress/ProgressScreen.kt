package com.dbworkout.ui.screens.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dbworkout.R
import com.dbworkout.ui.components.DrawerScaffold
import com.dbworkout.ui.components.LoadingPane
import com.dbworkout.ui.navigation.Routes
import com.dbworkout.ui.util.formatWeight
import com.dbworkout.viewmodel.ProgressViewModel

@Composable
fun ProgressScreen(viewModel:ProgressViewModel,onNavigate:(String)->Unit,onCreateWorkout:()->Unit){
 val state by viewModel.state.collectAsStateWithLifecycle()
 DrawerScaffold(title=stringResource(R.string.nav_progress),currentRoute=Routes.PROGRESS,onNavigate=onNavigate,onCreateWorkout=onCreateWorkout,actions={TextButton(onClick=viewModel::refresh){Text(stringResource(R.string.refresh))}}){padding->
  if(state.isLoading) LoadingPane(Modifier.padding(padding)) else LazyColumn(Modifier.fillMaxSize().padding(padding),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   item{StatsCard(stringResource(R.string.week_stats),state.week!!)}
   item{StatsCard(stringResource(R.string.month_stats),state.month!!)}
   item{Text(stringResource(R.string.week_chart),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold)}
   item{BarChart(state.week!!.daily.map{it.workoutCount},Modifier.fillMaxWidth().height(160.dp))}
   item{Text(stringResource(R.string.volume_note),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
  }
 }
}
@Composable private fun StatsCard(title:String,s:com.dbworkout.data.repository.ProgressStats){Card{Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(title,fontWeight=FontWeight.SemiBold);Text("Тренировок: ${s.workoutCount}");Text("Объём: ${s.totalVolumeKg.formatWeight()} кг");Text("Лучший вес: ${s.bestWeightKg.formatWeight()} кг")}}}
@Composable private fun BarChart(values:List<Int>,modifier:Modifier){Canvas(modifier){val max=(values.maxOrNull()?:1).coerceAtLeast(1);val gap=size.width/(values.size.coerceAtLeast(1)*2f);values.forEachIndexed{idx,v->val x=gap+idx*2*gap;val h=size.height*(v.toFloat()/max);drawRect(topLeft=Offset(x,size.height-h),size=androidx.compose.ui.geometry.Size(gap,h))}}}
