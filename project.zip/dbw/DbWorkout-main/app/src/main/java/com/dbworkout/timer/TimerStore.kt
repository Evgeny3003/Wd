package com.dbworkout.timer

import android.content.Context
import android.os.SystemClock

class TimerStore(context: Context) {
    private val prefs = context.getSharedPreferences("rest_timer", Context.MODE_PRIVATE)
    companion object { const val DEFAULT_MS = 180_000L; const val KEY_END="end_elapsed"; const val KEY_REMAINING="remaining"; const val KEY_RUNNING="running" }
    fun isRunning()=prefs.getBoolean(KEY_RUNNING,false)
    fun endElapsed()=prefs.getLong(KEY_END,0L)
    fun remaining():Long=if(isRunning()) (endElapsed()-SystemClock.elapsedRealtime()).coerceAtLeast(0L) else prefs.getLong(KEY_REMAINING,DEFAULT_MS)
    fun start(){ val r=remaining().takeIf{it>0}?:DEFAULT_MS; prefs.edit().putLong(KEY_END,SystemClock.elapsedRealtime()+r).putBoolean(KEY_RUNNING,true).apply() }
    fun pause(){ prefs.edit().putLong(KEY_REMAINING,remaining()).putBoolean(KEY_RUNNING,false).apply() }
    fun reset(){ prefs.edit().putLong(KEY_REMAINING,DEFAULT_MS).putLong(KEY_END,0L).putBoolean(KEY_RUNNING,false).apply() }
    fun finish(){ prefs.edit().putLong(KEY_REMAINING,0L).putLong(KEY_END,0L).putBoolean(KEY_RUNNING,false).apply() }
}
