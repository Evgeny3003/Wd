package com.dbworkout.data.local.entity

data class DailyWorkoutCount(
    val dateEpochDay: Long,
    val workoutCount: Int,
)
