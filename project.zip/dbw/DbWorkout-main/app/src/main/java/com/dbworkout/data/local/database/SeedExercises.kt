package com.dbworkout.data.local.database

import androidx.sqlite.db.SupportSQLiteDatabase
import com.dbworkout.model.ExerciseCategory

internal object SeedExercises {
    private val exercises = listOf(
        ExerciseCategory.CHEST to "Жим штанги лёжа",
        ExerciseCategory.LEGS to "Приседания со штангой",
        ExerciseCategory.LEGS to "Становая тяга",
        ExerciseCategory.BACK to "Подтягивания",
        ExerciseCategory.BACK to "Тяга верхнего блока",
        ExerciseCategory.CHEST to "Жим гантелей лёжа",
        ExerciseCategory.SHOULDERS to "Жим штанги над головой",
        ExerciseCategory.BICEPS to "Сгибания рук с гантелями",
        ExerciseCategory.TRICEPS to "Разгибание рук на блоке",
        ExerciseCategory.LEGS to "Выпады с гантелями",
    )

    fun populate(database: SupportSQLiteDatabase) {
        val createdAt = System.currentTimeMillis()
        exercises.forEach { (category, name) ->
            database.execSQL(
                "INSERT INTO exercises (name, category, isCustom, notes, createdAt) VALUES (?, ?, 0, NULL, ?)",
                arrayOf<Any>(name, category.name, createdAt),
            )
        }
    }
}
