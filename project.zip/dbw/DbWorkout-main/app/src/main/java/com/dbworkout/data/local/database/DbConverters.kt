package com.dbworkout.data.local.database

import androidx.room.TypeConverter
import com.dbworkout.model.ExerciseCategory
import com.dbworkout.model.Difficulty

class DbConverters {
    @TypeConverter
    fun fromCategory(category: ExerciseCategory): String = category.name

    @TypeConverter
    fun toCategory(value: String): ExerciseCategory = ExerciseCategory.valueOf(value)

    @TypeConverter
    fun fromDifficulty(value: Difficulty): String = value.name

    @TypeConverter
    fun toDifficulty(value: String): Difficulty = Difficulty.valueOf(value)
}
