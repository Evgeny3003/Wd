package com.dbworkout.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dbworkout.data.repository.ProgressStats
import com.dbworkout.data.repository.WorkoutRepository
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProgressUiState(val week: ProgressStats?=null,val month: ProgressStats?=null,val isLoading:Boolean=true)
class ProgressViewModel(private val repository:WorkoutRepository):ViewModel(){
 private val _state=MutableStateFlow(ProgressUiState());val state: StateFlow<ProgressUiState> =_state.asStateFlow()
 init{refresh()}
 fun refresh(){viewModelScope.launch{val now=LocalDate.now();_state.value=ProgressUiState(repository.progress(now.minusDays(6),now),repository.progress(now.withDayOfMonth(1),now.withDayOfMonth(now.lengthOfMonth())),false)}}
}
