package com.dbworkout.timer

import android.app.*
import android.content.*
import android.os.*
import android.media.AudioAttributes
import androidx.core.app.NotificationCompat
import com.dbworkout.MainActivity
import com.dbworkout.R

class RestTimerService : Service() {
    private lateinit var store: TimerStore
    private val handler=Handler(mainLooper)
    private val ticker=object:Runnable{override fun run(){if(store.isRunning()){val r=store.remaining();if(r<=0){store.finish();notifyFinished();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return};update(r);handler.postDelayed(this,500)} }}
    override fun onCreate(){super.onCreate();store=TimerStore(this);createChannel()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{when(intent?.action){ACTION_START->store.start();ACTION_PAUSE->store.pause();ACTION_RESET->store.reset()};if(store.isRunning()){startForeground(ID,notification(store.remaining(),false));handler.removeCallbacks(ticker);handler.post(ticker)}else update(store.remaining());return START_STICKY}
    private fun update(r:Long){getSystemService(NotificationManager::class.java).notify(ID,notification(r,false))}
    private fun notifyFinished(){getSystemService(NotificationManager::class.java).notify(ID,notification(0,true))}
    private fun notification(r:Long,finished:Boolean)=NotificationCompat.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_launcher_monochrome).setContentTitle(if(finished)"Отдых завершён" else "Таймер отдыха").setContentText(if(finished)"Можно выполнять следующий подход" else format(r)).setContentIntent(PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)).setOngoing(!finished).setOnlyAlertOnce(!finished).setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_ALARM).build()
    private fun format(ms:Long):String{val s=(ms/1000).coerceAtLeast(0);return "%02d:%02d".format(s/60,s%60)}
    private fun createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            val channel = NotificationChannel(CHANNEL,"Таймер отдыха",NotificationManager.IMPORTANCE_HIGH).apply{
                enableVibration(true)
                setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    override fun onDestroy(){handler.removeCallbacks(ticker);super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
    companion object{const val ACTION_START="com.dbworkout.timer.START";const val ACTION_PAUSE="com.dbworkout.timer.PAUSE";const val ACTION_RESET="com.dbworkout.timer.RESET";private const val CHANNEL="rest_timer";private const val ID=3001}
}
